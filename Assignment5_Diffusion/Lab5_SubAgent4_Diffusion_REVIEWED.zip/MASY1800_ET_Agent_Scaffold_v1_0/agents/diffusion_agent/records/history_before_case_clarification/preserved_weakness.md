# Observed test weakness — raw evidence preserved

Primary source: responses/actual/raw/primary_run_01.json. Expected primary adoption_posture: willing early experimenter. Returned organization finding and evidence describe a conservative fast follower. This could be a changed prompt or model drift; the exact originating input is unknown, so cause is not assigned. User clarification pending. The returned context resembles contrast_2. Both JSON/schema checks pass, demonstrating why structural validity alone cannot establish case adherence.

The output-to-input posture review flagged this issue. No specialist revision, repaired output or model retest is claimed. Same-conversation outputs do not prove independent replication. Full excerpts and disposition are in paired_response_review.md. Earlier evidence-access limitations remain in history and source_ledger.json.
