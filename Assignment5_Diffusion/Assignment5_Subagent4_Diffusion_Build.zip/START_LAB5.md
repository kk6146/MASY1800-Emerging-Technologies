# START HERE — Lab 5 / SubAgent 4: Diffusion

1. Read Lab5_SubAgent4_Diffusion_Report.docx and Lab5_Agent_Record.docx in the scaffold's agents/diffusion_agent/records/lab5/ folder.
2. Open primary_prompt.txt at the top of this ZIP. Paste ALL of it into a fresh ordinary ChatGPT chat. Save the full response unchanged.
3. Repeat contrast_1_prompt.txt with the same model/source availability. Optional contrast_2_prompt.txt isolates posture.
4. Return responses to the development chat labeled DIFFUSION PRIMARY ACTUAL RESPONSE and DIFFUSION CONTRAST ACTUAL RESPONSE. Include model/source details if known. Errors and invalid JSON should be preserved.
5. The developer can then execute actual response validation, compare observed results and update the Agent Record. Output-report/model-weakness/revision/retest requirements are pending until that evidence exists.

The agent and prompt workflow are built. This is not labeled as a completed tested submission. Fill student identity and review personal judgment/learning statements before submission. Original course documents remain unchanged. No model output is fabricated.
