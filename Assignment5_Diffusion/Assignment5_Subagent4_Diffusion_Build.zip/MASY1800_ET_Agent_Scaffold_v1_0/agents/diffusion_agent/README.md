# Subagent 4 — Diffusion (Assignment 5)

Built from the uploaded frozen v1.0 scaffold. Specialization is in this folder; architecture, schema and tools are unchanged. This is the Diffusion specialist, not the Adoption or Promethean specialist.

Example cases use the same GenAI technology: primary = online retailer; contrast_1 = hospital clinical support; contrast_2 = identical retailer with conservative posture. Cases are hypothetical and replaceable. General diffusion evidence should remain stable while local timing is interpreted separately.

Actual ChatGPT response capture is pending. No generated sample is counted as a run. Local build/integrity checks are in records/local_checks.json. Prompt packets are generated in scaffold work/. See records/chatgpt_run_guide.md for actual runs, and records/requirements_review.md for scope and remaining requirements.

The five categories and five characteristics follow Rogers; source definition, dates, geography and denominator must support any stage claim. The common source envelope deliberately exposes broad-AI versus GenAI/application scope gaps. Do not claim a current exact GenAI diffusion stage from those sources.
