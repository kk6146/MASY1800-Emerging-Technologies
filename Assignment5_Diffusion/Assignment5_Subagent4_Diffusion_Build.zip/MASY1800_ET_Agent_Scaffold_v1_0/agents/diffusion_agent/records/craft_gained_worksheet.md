# Craft Gained — student worksheet (final answer: 100 words or fewer)

Complete after your actual runs and source checks. What specifically changed in your judgment about diffusion? Which source mismatch, factor analysis, failed output or contrast caused that change? How will your next evaluation differ? Do not claim a learning experience or execution that did not occur.

Useful evidence to consider: broader AI versus GenAI application scope, changed questionnaires, declared posture versus historical category, and visible pilots versus sustained use. Your final statement should describe your own discovery, not merely restate these concepts.
