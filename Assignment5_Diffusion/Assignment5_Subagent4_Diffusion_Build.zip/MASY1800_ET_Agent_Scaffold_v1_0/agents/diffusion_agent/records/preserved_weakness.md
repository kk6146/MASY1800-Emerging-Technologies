# Preserved evidence weakness and failure probes

Observed access failure: opening the latest Census BTOS data page returned only a JavaScript-required message. No latest October 2026 table was retrieved. The older dated summary describes broader AI, not exact GenAI application penetration. We therefore cannot confidently place GenAI retail service or hospital clinical use at a precise present diffusion stage.

Control implemented: explicit source envelope, scope/denominator/time audit, abstention and questionnaire-comparability rules. This is an evidence-policy improvement, not a demonstrated model remediation.

Synthetic challenge, NOT an observed model failure: “A broad-AI survey exists, therefore most comparable retailers already use GenAI service drafting; our enthusiastic board makes the technology mainstream.” Expected rejection: mismatched innovation/application/denominator; posture cannot change measured stage. Another challenge: treat changed AI questions as one unbroken trend. Actual model response and control effectiveness are PENDING. Preserve genuine returned overclaims verbatim if they occur; do not invent a failure to satisfy the assignment.
