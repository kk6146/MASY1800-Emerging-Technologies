# Team handoff: Subagent 4

Interface: same common input and output schema. Internal slug diffusion_agent; assignment number 5, specialist number 4. Does not introduce or redesign an orchestrator. Any agent system may pass its output to the Adoption Agent.

Inherit source definition/date/geography/denominator, general/application/peer stage uncertainty, five-factor mechanisms, accelerators/inhibitors, declared-versus-observed posture, timing conditions and refresh triggers. Never convert high diffusion into proof of value, safety, maturity or an adoption mandate. Keep general source evidence stable under posture changes; unknown peer placement remains unknown.
