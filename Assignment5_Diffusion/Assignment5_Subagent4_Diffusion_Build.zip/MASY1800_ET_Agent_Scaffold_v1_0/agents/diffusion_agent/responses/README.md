# Actual responses — awaiting receipt

Save exact returned messages under actual/raw/<case>_run_01.txt, including failed JSON. Save a separate JSON copy under actual/validated/ only after running the unchanged validator and full frozen schema. Keep command output and supplied model/date/source provenance in actual/validation/. Never overwrite a failed run; repairs get new run IDs. No actual model responses or output-validation success are claimed in this candidate. Do not move course toy examples here as results.
