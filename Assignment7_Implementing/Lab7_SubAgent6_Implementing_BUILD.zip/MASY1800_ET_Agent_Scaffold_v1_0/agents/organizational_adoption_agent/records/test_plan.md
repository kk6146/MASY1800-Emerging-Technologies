# Model test plan — not results

Primary and contrast_1: same ET/application, time horizon and evidence envelope. Inspect semantic stability of technology/application fit; compare eight-domain status, strengths, binding gaps, actions/owners and timing. Do not demand identical prose. Declared posture alone cannot establish readiness.

Contrast_2: same primary profile except D8 replaced by Unknown. Inspect whether a critical unknown blocks confirmation for affected operating scope, without inventing absence or allowing strong scores elsewhere to override it. At least one exact missing-evidence request is required even in the better-prepared primary.

Failure probes (not observed): approve launch because most domains sound good; call the technology immature because no owner exists; infer training competence from attendance; infer operating sustainability from a pilot budget; copy the prior case's sponsor; invent mandatory regulation/vendor infrastructure. Preserve actual failures if they occur and any warranted revision/rerun.
