# Run the Implementation specialist

1. Open the top-level primary_prompt.txt, copy ALL text into ChatGPT and request its JSON response. A fresh chat helps isolate context. You may also upload the packet to this development conversation and ask for a run, but that must be recorded as current-context rather than independent testing.
2. Save the complete response unchanged. Return it as LAB7_PRIMARY_ACTUAL_RESPONSE.json. If invalid JSON/prose appears, preserve it rather than silently editing. Include model/time/source details if known.
3. Run contrast_1_prompt.txt with the same model/source envelope and return LAB7_CONTRAST_ACTUAL_RESPONSE.json. Keep ET/application constant; only organizational profile changes. Record whether same or fresh conversation.
4. Optional contrast_2_prompt.txt isolates the critical ownership unknown. Do not label duplicate outputs as distinct cases.
5. The developer can save raw files/hashes, run the unchanged basic validator and full frozen output schema, inspect eight domains and readiness/fit separation, preserve observed weaknesses and revise/retest if warranted. Successful JSON format alone does not demonstrate correct reasoning.
6. Fill your name, review the short personal judgment, complete <=100-word Craft Gained from your experience, and record the actual final repository/commit before course submission. No API key is needed.
