# Team handoff — SubAgent 6 Implementing

Common input/output contract unchanged. Readiness context uses existing organization, capabilities_constraints, risk_consequence_context and related fields; no schema additions are required. Preserve exact organizational profile, evidence status, intended operating scope and upstream adoption posture in orchestration.

Receive the Adoption Agent's strategically bounded posture without treating it as implementation authorization. Return technology/application fit separately from eight-domain readiness, binding critical gate, strongest strength, proposed accountable roles/actions, unresolved artifacts and review triggers. Do not certify legal compliance, invent real owners or equate low readiness with technology immaturity. Operating ownership after pilot is a required sustainment concern.
