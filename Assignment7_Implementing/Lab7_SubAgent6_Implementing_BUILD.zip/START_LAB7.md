# START HERE — Lab 7 / SubAgent 6 Implementing

This is the Organizational Adoption Agent build, not a completed tested submission.

1. Read the enclosed scaffold's agents/organizational_adoption_agent/records/lab7/Lab7_SubAgent6_Implementing_Report.docx and Lab7_Agent_Record.docx.
2. Open primary_prompt.txt at the TOP of this ZIP. Copy all text into a fresh ChatGPT chat, or upload it to your development conversation and ask for an explicitly labeled current-context run.
3. Save the complete returned message unchanged; return it as LAB7_PRIMARY_ACTUAL_RESPONSE.json. Record model/time/source context if known. Keep failures and avoid HTML/Markdown escaping.
4. Repeat contrast_1_prompt.txt for the same GenAI retail drafting application in a less-prepared organization. Keep model/source context comparable; disclose whether separate or same conversation.
5. Optional contrast_2_prompt.txt changes only D8 operating ownership to Unknown. This is a critical-evidence probe, not an additional completed run.
6. Return actual outputs for frozen-schema validation, eight-domain/fit/readiness comparison, observed weakness and warranted revision/retest. Do not count constructed examples or duplicated files as tests.
7. Fill student identity, personal judgment, <=100-word Craft Gained and actual delivery provenance before course submission.

All common files, original template, schemas and tools are unchanged. No current vendor/regulatory claims or real-organization observations are invented. The Adoption Agent's strategic interest does not authorize implementation; this specialist returns scoped readiness and role-owned conditions.
