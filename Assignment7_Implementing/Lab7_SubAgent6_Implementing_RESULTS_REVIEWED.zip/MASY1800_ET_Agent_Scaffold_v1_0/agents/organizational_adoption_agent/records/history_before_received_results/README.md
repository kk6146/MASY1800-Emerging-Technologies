Build-time pending status before three result artifacts arrived. Current records supersede it; these files are not current test results.
