# Observed weaknesses and revision status

Actual returned-artifact weaknesses: escaped pasted JSON fails parsing; three received uploads carry one unique Contrast 1 DEFER response. Raw originals and errors are retained. Explicit formatting-only normalized derivatives pass schema; no model text was substantively repaired. Duplicate hashing/case mapping prevents counting them as a three-case test.

Controls applied: preserve raw/normalized/validation separation, label one unique contrast result, quarantine constructed reference examples and update status honestly. Plain JSON export and distinct case-specific filenames are the proposed process fix. No successful model retest or primary/PoC result is invented. Original hypothetical productivity-only design weakness remains in before_response_review/ and is not relabeled as an observed model failure.
