# Craft Gained — proposed draft, under 100 words

I learned to separate a valid-looking response from usable test evidence. Three pasted uploads contained the same conservative case, and export formatting made the raw text invalid JSON. Preserving originals, logging a formatting-only repair and capturing the missing primary clarified what was actually evaluated. Next time I will save plain JSON with case labels and provenance immediately, compare operational permissions rather than posture labels alone, and keep shared-context comparisons separate from independent replication claims.

Use only if it accurately reflects your learning; edit and own it before submission.
