# Preserved weakness and correction

Observed failures: all three raw pasted exports failed JSON because of HTML indentation and line-ending backslashes; their content was the same conservative DEFER case. Duplicates could not establish primary/contrast responsiveness. Cause of export formatting is unknown and not assigned to the model.

Applied process correction: retain raw files and errors; create formatting-only normalized derivatives with exact recipes/hashes; isolate constructed references; use the user-supplied primary packet for an explicitly captured current-conversation primary response. Basic/full-schema checks on that primary and normalized contrast pass. The correction is verified at artifact/validation level, not an independent new model test. Original primary/contrast text is retained unchanged.

Specialist version remains 1.0. No successful specialist revision/retest, isolated model invocation or optional actual PoC run is invented. Same-context anchoring and deliberately identical general/application fields remain limitations. Historical design-stage productivity-only weakness remains in before_response_review/.
