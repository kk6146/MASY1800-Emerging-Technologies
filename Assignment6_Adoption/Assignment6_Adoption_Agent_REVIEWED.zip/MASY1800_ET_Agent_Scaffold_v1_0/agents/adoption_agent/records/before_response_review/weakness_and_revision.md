# Preserved diagnostic weakness and revision — 2026-11-09

**Initial draft decision rule (design-stage weakness, not an observed LLM run):** “If generative AI can increase productivity, recommend adoption for customer service.”

**Why this fails:** It collapses general technology capability into an organization-wide recommendation, ignores missing evidence and would produce the same answer for both retailers.

**Revision:** Added explicit adoption categories, a non-negotiable privacy/safety gate, comparison with alternatives, reversibility and consequence checks, and a rule that organizational risk posture changes action but not general maturity evidence.

**Re-test with saved structured sample responses:** Primary = BOUNDED EXPERIMENT; conservative contrast = DEFER; general finding remains identical. The saved outputs are constructed reference executions of the specialist logic, not independent live ChatGPT inference. Live prompt-packet tests are still recommended before final instructor submission.
