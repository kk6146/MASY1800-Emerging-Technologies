# Response provenance

current_conversation/primary_run_01.json: assistant response to the exact user-uploaded primary packet in this ongoing conversation; validation/provenance beside it.
received/raw/: three original escaped pasted uploads, invalid as raw JSON, all representing the same conservative Contrast 1.
received/normalized/: explicit formatting-only derivatives; same unique result, not three distinct cases.
received/validation/: errors, repairs, hashes and executed checks.
../reference_examples/: constructed source-package examples, not actual runs.

No output should be silently overwritten, relabeled or presented as independent fresh-chat testing.
