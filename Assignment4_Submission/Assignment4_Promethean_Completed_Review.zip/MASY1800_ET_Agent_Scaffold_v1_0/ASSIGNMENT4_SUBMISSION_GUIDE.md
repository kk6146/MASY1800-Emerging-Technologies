# Assignment 4 prepared package

The delivered folder retains the frozen version 1.0 scaffold unchanged and adds `agents/promethean_classification_agent`. Read its README and `records/agent_record.md`.

## Tests performed
- Local frozen-core SHA-256 integrity checker: PASS.
- Prompt packet generation for primary, contrast_1 and contrast_2: PASS.
- Local structural validator for all three **illustrative analyst-authored** JSON responses: PASS.
- General ET finding byte-for-byte stable across cases; organizational recommendations deliberately differ.

## Required student completion before submission
1. Upload working copy to your own GitHub repository and enter actual repo / branch / commit in Agent Record.
2. Run the generated `work/promethean_classification_agent_*_prompt.txt` files in ChatGPT (with appropriate source verification), capture actual JSON outputs and validate them, replacing dry-runs or labeling dry-runs separately.
3. Preserve one **observed** weak model result and describe your actual revision; synthetic failure probe alone is not an observed failure.
4. Review and personalize independent judgment, AI/verification and Craft Gained notes; submit agent output and required reports per Brightspace.
