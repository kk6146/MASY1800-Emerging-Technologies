from pathlib import Path
from datetime import datetime, timezone
import json,subprocess,hashlib,importlib.metadata
from jsonschema import Draft202012Validator
r=Path('/workspace/MASY1800-Emerging-Technologies/MASY1800_ET_Agent_Scaffold_v1_0');a=r/'agents/promethean_classification_agent';rec=a/'records';ev=rec/'execution_evidence';ev.mkdir(exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def run(args):
 start=datetime.now(timezone.utc).isoformat()
 p=subprocess.run(args,cwd=r,text=True,capture_output=True)
 checks.append({'command':args,'cwd':str(r),'started_at_utc':start,'finished_at_utc':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 assert p.returncode==0,p.stderr+p.stdout
 return p
run(['python','tools/check_frozen_core.py'])
frozen={}
for line in (r/'FROZEN_CORE_SHA256.txt').read_text().splitlines():
 expected,rel=line.split('  ',1);assert digest(r/rel)==expected;frozen[rel]=expected
uploaded_manifest=next(Path('/workspace/attachments').glob('*/FROZEN_CORE_SHA256.txt'))
assert uploaded_manifest.read_bytes()==(r/'FROZEN_CORE_SHA256.txt').read_bytes()
chapter=next(Path('/workspace/attachments').glob('*/Chapter11_Identifying_Promethean_Technologies*.pdf'))
sessions=[]
for name,label in [('primary','retail'),('contrast_1','hospital'),('contrast_2','hype')]:
 run(['python','tools/build_prompt.py','--agent','agents/promethean_classification_agent','--case',f'agents/promethean_classification_agent/cases/{name}.json'])
 case=a/f'cases/{name}.json';packet=r/f'work/promethean_classification_agent_{name}_prompt.txt'
 schema=json.loads((r/'core/input_schema.json').read_text());Draft202012Validator.check_schema(schema)
 Draft202012Validator(schema).validate(json.loads(case.read_text()))
 text=packet.read_text()
 assert (r/'core/common_instructions.md').read_text() in text
 assert (a/'specialist_instructions.md').read_text() in text
 assert json.dumps(json.loads((r/'core/output_schema.json').read_text()),indent=2) in text
 sessions.append({'case':name,'label':label,'agent_version':'1.2-evaluation-candidate','packet_path':str(packet.relative_to(r)),'packet_sha256':digest(packet),'case_sha256':digest(case),'specialist_sha256':digest(a/'specialist_instructions.md'),'source_attachment':{'filename':chapter.name,'sha256':digest(chapter)},'status':'awaiting_response','model':None,'model_timestamp':None,'raw_response_path':None,'raw_response_sha256':None,'response_validation':'not_run_no_response','semantic_review':'pending','observed_model_weakness':None})
run(['python','tools/check_frozen_core.py'])
(ev/'frozen_hashes.json').write_text(json.dumps(frozen,indent=2)+'\n')
(ev/'run_registry.json').write_text(json.dumps(sessions,indent=2)+'\n')
result={'status':'preparation_checks_passed_actual_model_runs_pending','recorded_at_utc':datetime.now(timezone.utc).isoformat(),'jsonschema_version':importlib.metadata.version('jsonschema'),'commands':checks,'additional_executed_checks':['All three case files satisfy the unchanged full input schema.','All three packets contain exact common instructions, current specialist, and frozen output schema.','Frozen manifest is identical to originally uploaded manifest.'],'actual_responses_received':0,'actual_output_schema_validations':0,'actual_model_behavior_tests':0,'submission_ready':False}
(ev/'local_checks.json').write_text(json.dumps(result,indent=2)+'\n')
(rec/'test_results.txt').write_text('CURRENT STATUS: preparation only; no actual ChatGPT responses received.\n\n'+''.join('$ '+' '.join(x['command'])+'\n'+x['stdout']+x['stderr']+f'exit={x["exit_code"]}\n\n' for x in checks)+'PASS: 3 input schema checks and 3 packet-content checks.\nActual response validations: 0 (pending).\nObserved model behavior comparisons: not performed.\nFinal submission readiness: blocked pending actual response evidence and student review.\n')
(rec/'chatgpt_run_guide.md').write_text('''# Run in ChatGPT and preserve evidence

1. Start a fresh ordinary ChatGPT conversation. Attach Chapter11_Identifying_Promethean_Technologies_v0.1_WITH_FIGURES (2).pdf. Do not attach illustrative outputs or expected verdicts beyond the specialist's source calibration.
2. Paste the FULL primary packet generated in scaffold work/promethean_classification_agent_primary_prompt.txt. This includes exact frozen common instructions and output schema, current specialist, metadata and retail case. Request JSON only. Do not ask for a polished example or expected result. Use the same model/source availability/browsing setting for the contrast. Record the model label shown and date/time if available; unknown is acceptable.
3. Copy the complete returned message unchanged. Send it back to this assistant labeled PRIMARY ACTUAL RESPONSE, including any prose, code fences or invalid JSON. A failed output is useful evidence. If convenient, upload it as primary_actual_response.txt or .json. Include conversation export/link or screenshots if available, but never fabricate them. No personal customer/patient data is needed.
4. Repeat in a separate fresh conversation with the hospital packet, work/promethean_classification_agent_contrast_1_prompt.txt, and the SAME chapter/source availability. Return it labeled CONTRAST ACTUAL RESPONSE. Preserve all failed or repaired versions separately. Optional third run: hype case contrast_2.
5. This assistant will save exact received bytes/text under responses/chatgpt/raw/, record supplied provenance and hashes, parse without silently repairing, execute tools/validate_response.py and full frozen JSON Schema validation on the returned JSON, and save diagnostics. Only then can a separate validated JSON copy be made. Code fences/prose are output-discipline defects even if JSON can be extracted into a separate file; retain the original.
6. Compare the actual general classification and sources semantically, not byte-for-byte; different phrasing is normal. Look for unjustified general drift, missing diagnostics, unsupported confidence, hype compliance, local adoption overclaims, incomplete opposing evidence and abstention. Preserve one observed weakness with exact field/excerpt. If no meaningful weakness appears, record that honestly; do not manufacture a failure. Adversarial follow-up may provide additional evidence.
7. Revise only specialist files when evidence warrants it; freeze and hash the revised packet; rerun as a new version/run ID. Do not silently overwrite earlier raw output. Update the Agent Record with observed stable/changed findings and real validator results, then check the final ZIP. Final readiness also requires student's actual identity, provenance and ownership of judgment/learning drafts.

If the packet file cannot be accessed in this interface, ask this assistant to paste the primary packet into chat. It can be copied directly. Packet preparation does not itself run the model. No OpenAI API is used by the scaffold.
''')
print(json.dumps({'executed_local_commands':len(checks),'case_schema_checks':3,'packets_built':3,'actual_responses_received':0,'actual_model_tests':'pending','frozen':'intact','submission_ready':False},indent=2))
