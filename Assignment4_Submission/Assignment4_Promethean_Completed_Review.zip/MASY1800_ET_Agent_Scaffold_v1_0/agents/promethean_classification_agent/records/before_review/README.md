# Promethean Technology Classification Agent — Assignment 4

This is a student-editable specialist created from the supplied frozen MASY1800 v1.0 scaffold. **The frozen core remains unchanged.**

- `specialist_instructions.md`: Chapter 11 significance rubric, evidentiary rules, uncertainty, hype and three-level discipline.
- `cases/primary.json`: retail support.
- `cases/contrast_1.json`: hospital decision support.
- `cases/contrast_2.json`: hype pressure / aggressive retailer.
- `responses/`: analyst-generated illustrative structured responses (NOT calls to a deployed AI API).
- `records/agent_record.md`: decision, testing, limitations and integration note; fill in your real GitHub repo/branch/commit after committing.

From repository root run `python tools/check_frozen_core.py`; `python tools/build_prompt.py --agent agents/promethean_classification_agent --case agents/promethean_classification_agent/cases/primary.json`; and `python tools/validate_response.py agents/promethean_classification_agent/responses/primary_response.json`. Repeat for contrasts.
