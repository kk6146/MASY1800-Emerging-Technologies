# Captured user-supplied responses

Primary and hospital contrast run_01 artifacts have been received as user uploads, preserved exactly under raw/, and copied byte-for-byte under validated/ only after actual validation. Diagnostics are in validation/. Provenance is user-supplied; originating model/session/time/exact inputs and source attachments are not independently captured. Hype response remains pending/not executed. Earlier illustrative examples are separate. Never overwrite a raw run or silently repair an output.
